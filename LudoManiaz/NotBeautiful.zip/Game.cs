﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LudoManiaz
{
    class Game
    {
        public int[,] int3DTo2D(int[,,] inp, int item0, int item1)
        {
            int[,] res = new int[,]
            {
                { inp[ item0, item1, 0], inp[ item0, item1, 0] }
            };

            return res;
        }
        public int[] int2DTo1D(int[,] inp, int item)
        {
            int[] res = new int[]
            {
                inp[item, 0],
                inp[item, 1]
            };

            return res;
        }
    }
}
